//app/api/gitlab/commits/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getGitLabClientOrFail, handleApiError } from '@/lib/api-helpers';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const refName = searchParams.get('ref_name') || undefined;
    const perPage = parseInt(searchParams.get('per_page') || '100');
    const projectId = searchParams.get('projectId');

    if (!projectId) {
      const client = await getGitLabClientOrFail();
      const commits = await client.getCommits(refName, perPage);
      return NextResponse.json(commits);
    }

    // Use specific project ID from frontend
    const { readConfig, decryptToken } = await import('@/lib/config.server');
    const config = await readConfig();
    const ENCRYPTION_KEY = process.env.CONFIG_ENCRYPTION_KEY;
    
    if (!config || !ENCRYPTION_KEY) {
      throw new Error('Configuration error');
    }

    const project = config.projects.find(p => p.projectId === projectId);
    if (!project) {
      throw new Error(`Project with ID ${projectId} not found`);
    }

    const token = decryptToken(
      project.tokenCiphertext,
      project.tokenNonce,
      project.tokenTag,
      ENCRYPTION_KEY
    );

    const { GitLabAPIClient } = await import('@/lib/gitlab');
    const client = new GitLabAPIClient(
      project.gitlabHost,
      token,
      project.projectId
    );

    const commits = await client.getCommits(refName, perPage);
    
    return NextResponse.json(commits);
  } catch (error) {
    return handleApiError(error);
  }
}